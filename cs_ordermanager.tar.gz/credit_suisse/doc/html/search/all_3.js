var searchData=
[
  ['duplicate_5fid',['duplicate_id',['../namespacecs_1_1feed__errors.html#afcf5776a3b76b8a3c1ab14d4bf14a7de',1,'cs::feed_errors']]],
  ['duplicate_5forder_5fid',['DUPLICATE_ORDER_ID',['../namespacecs_1_1feed__errors.html#afaa0de33a8b96625db315f7fee92bcfbadf775b6a054c823c396943bd5d68ada7',1,'cs::feed_errors']]]
];
