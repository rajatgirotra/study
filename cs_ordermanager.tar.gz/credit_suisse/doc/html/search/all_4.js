var searchData=
[
  ['error_5fcounter',['error_counter',['../classcs_1_1feed__errors_1_1error__counter.html',1,'cs::feed_errors']]],
  ['error_5fcounter',['error_counter',['../classcs_1_1feed__errors_1_1error__counter.html#ac4b2eda8fe8b7ffd05d8db41fe930892',1,'cs::feed_errors::error_counter']]],
  ['errors',['Errors',['../namespacecs_1_1feed__errors.html#afaa0de33a8b96625db315f7fee92bcfb',1,'cs::feed_errors::Errors()'],['../namespacecs_1_1feed__errors.html#a244840c4602b0fdb6384f5b84f108a85',1,'cs::feed_errors::errors()'],['../namespacecs_1_1feed__errors.html#a70a4da10871300e03fc75b9880574b07',1,'cs::feed_errors::errors(corrupted_msg, duplicate_id, trade_with_no_order, remove_with_no_order, crossed_book_no_trades, invalid_order_id, invalid_price, invalid_qty, invalid_product_id, invalid_side)']]],
  ['errors_2ecpp',['errors.cpp',['../errors_8cpp.html',1,'']]],
  ['errors_2ehpp',['errors.hpp',['../errors_8hpp.html',1,'']]]
];
