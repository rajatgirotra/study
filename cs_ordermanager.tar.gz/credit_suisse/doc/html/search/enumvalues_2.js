var searchData=
[
  ['corrupted_5fmsg',['CORRUPTED_MSG',['../namespacecs_1_1feed__errors.html#afaa0de33a8b96625db315f7fee92bcfba3f0ac79b68247b1e6fcc4a87715dd6d9',1,'cs::feed_errors']]],
  ['crossed_5fbook_5fno_5ftrades',['CROSSED_BOOK_NO_TRADES',['../namespacecs_1_1feed__errors.html#afaa0de33a8b96625db315f7fee92bcfba71c4e11e0b88b1275c6ae2e58f99dad3',1,'cs::feed_errors']]]
];
