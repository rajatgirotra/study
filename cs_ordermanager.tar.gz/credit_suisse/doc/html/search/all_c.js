var searchData=
[
  ['remove_5fwith_5fno_5forder',['remove_with_no_order',['../namespacecs_1_1feed__errors.html#ae747f52a4a5da2bce55293f7964a0f5e',1,'cs::feed_errors::remove_with_no_order()'],['../namespacecs_1_1feed__errors.html#afaa0de33a8b96625db315f7fee92bcfbace953422a429e4653d2e5df6d9dbcf1a',1,'cs::feed_errors::REMOVE_WITH_NO_ORDER()']]],
  ['reset',['reset',['../classcs_1_1feed__errors_1_1error__counter.html#a924d4c05382e736c266b041fb910ee7b',1,'cs::feed_errors::error_counter']]],
  ['resting_5forder_2ecpp',['resting_order.cpp',['../resting__order_8cpp.html',1,'']]],
  ['resting_5forder_2ehpp',['resting_order.hpp',['../resting__order_8hpp.html',1,'']]],
  ['restingorder',['RestingOrder',['../structcs_1_1RestingOrder.html',1,'cs']]],
  ['restingorder',['RestingOrder',['../structcs_1_1RestingOrder.html#a8fc69ea4cbd25619a77628e6d321b28a',1,'cs::RestingOrder']]]
];
