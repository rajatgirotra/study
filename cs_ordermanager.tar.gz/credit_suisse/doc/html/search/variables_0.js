var searchData=
[
  ['corrupted_5fmsg',['corrupted_msg',['../namespacecs_1_1feed__errors.html#a9340f1e5a112b59943a96d9eb75c13ac',1,'cs::feed_errors']]],
  ['crossed_5fbook_5fno_5ftrades',['crossed_book_no_trades',['../namespacecs_1_1feed__errors.html#a1c21ff2128d38f464cb50d8007b8d381',1,'cs::feed_errors']]]
];
