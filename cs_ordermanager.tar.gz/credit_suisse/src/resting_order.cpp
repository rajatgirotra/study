// Copyright (C) 2016 by RajatGirotra
#include "resting_order.hpp"

namespace cs {

RestingOrder::RestingOrder(const uint32_t& prdid, const uint32_t& id, Side side,
                           const uint32_t& qty, const double& px,
                           const uint64_t& nanos) :
    m_productid(prdid), m_orderid(id), m_side(side), m_qty(qty), m_px(px),
    m_nanos(nanos) {}
}  // namespace cs

