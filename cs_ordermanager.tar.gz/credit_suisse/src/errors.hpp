// Copyright (C) 2016 by RajatGirotra
#pragma once

#include <cstdint>
#include <string>
#include <tuple>

namespace cs { namespace feed_errors {
/** Enum of possible errors in input
 */
enum Errors {
    CORRUPTED_MSG = 0,
    DUPLICATE_ORDER_ID,
    TRADES_WITH_NO_ORDER,
    REMOVE_WITH_NO_ORDER,
    CROSSED_BOOK_NO_TRADES,
    INVALID_ORDER_ID,
    INVALID_PRICE,
    INVALID_QTY,
    INVALID_PRODUCT_ID,
    INVALID_SIDE
};


/** error_counter class to maintain count of each type of error in input
 */        
template <enum Errors>
class error_counter {
    uint32_t m_count;
    std::string m_name;
 public:
    explicit error_counter(
        const std::string& name) : m_count(0),
                                   m_name(name) {
    }

    void operator ++() { ++m_count; }
    void operator ++(int) { operator++(); }
    void reset() { m_count = 0; }
    const uint32_t& count() const { return m_count; }
    const std::string& name() const { return m_name; }
};

/// object to count corrupted messages.
extern error_counter<Errors::CORRUPTED_MSG> corrupted_msg;
extern error_counter<Errors::DUPLICATE_ORDER_ID> duplicate_id;
extern error_counter<Errors::TRADES_WITH_NO_ORDER> trade_with_no_order;
extern error_counter<Errors::REMOVE_WITH_NO_ORDER> remove_with_no_order;
extern error_counter<Errors::CROSSED_BOOK_NO_TRADES> crossed_book_no_trades;
extern error_counter<Errors::INVALID_ORDER_ID> invalid_order_id;
extern error_counter<Errors::INVALID_PRICE> invalid_price;
extern error_counter<Errors::INVALID_QTY> invalid_qty;
extern error_counter<Errors::INVALID_PRODUCT_ID> invalid_product_id;
extern error_counter<Errors::INVALID_SIDE> invalid_side;

/// a tuple holding an error counter for each type of input error.
extern std::tuple<error_counter<Errors::CORRUPTED_MSG>&,
                  error_counter<Errors::DUPLICATE_ORDER_ID>&,
                  error_counter<Errors::TRADES_WITH_NO_ORDER>&,
                  error_counter<Errors::REMOVE_WITH_NO_ORDER>&,
                  error_counter<Errors::CROSSED_BOOK_NO_TRADES>&,
                  error_counter<Errors::INVALID_ORDER_ID>&,
                  error_counter<Errors::INVALID_PRICE>&,
                  error_counter<Errors::INVALID_QTY>&,
                  error_counter<Errors::INVALID_PRODUCT_ID>&,
                  error_counter<Errors::INVALID_SIDE>&
                          > errors;
}  // namespace feed_errors
}  // namespace cs
