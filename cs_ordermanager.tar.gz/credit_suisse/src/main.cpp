// Copyright (C) 2016 by RajatGirotra

#include "feed_handler.hpp"
#include <iostream>
#include <string>
#include <cstdio>
#include <chrono>
using std::cout;
using std::endl;
using std::string;
using namespace cs;

int main(int argc, char* argv[]) {
    auto start = std::chrono::steady_clock::now();
    if (argc != 2) {
        cout << "Usage:\n\t" << argv[0] << " <message_file>\n";
        return -1;
    }
    FeedHandler feed;
    // assume each line is under 100 bytes
    char line[101];
    auto counter = 0;
    FILE* poFile{};
    poFile = fopen(argv[1], "r");
    while (fgets(line, 100, poFile)) {
        feed.processMessage(line);
        if (++counter % 10 == 0) {
            feed.printCurrentOrderBook(cout);
        }
    }
    fclose(poFile);  // close file
    feed.printCurrentOrderBook(cout);
    feed.printErrorSummary(cout);
    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double> time_span = std::chrono::duration_cast<std::chrono::duration<double>>(end - start);
    std::cout << "Time span " << time_span.count() << " seconds\n";
    return 0;
}
