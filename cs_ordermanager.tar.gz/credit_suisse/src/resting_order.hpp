// Copyright (C) 2016 by RajatGirotra
#pragma once
#include "common.hpp"
#include <cstdint>
#include <boost/shared_ptr.hpp>

namespace cs {
/** Structure representing an item on the order book.
 */
struct RestingOrder {
    typedef boost::shared_ptr<RestingOrder> Ptr;

    uint32_t m_productid;
    uint32_t m_orderid;
    Side m_side;
    uint32_t m_qty;
    double m_px;
    uint64_t m_nanos;  // time when the order was received.

    RestingOrder(const uint32_t& prdid, const uint32_t& id, Side side,
                 const uint32_t& qty, const double& px, const uint64_t& nanos);

};
}  // namespace cs
