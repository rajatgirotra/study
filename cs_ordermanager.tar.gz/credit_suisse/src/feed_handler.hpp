// Copyright (C) 2016 by RajatGirotra
#pragma once

#include <boost/scoped_ptr.hpp>
#include <boost/unordered_map.hpp>
#include <string>

namespace cs {

class OrderBook;  // forward declarations
class feed_order;
class feed_trade;

/** Class to process input messages (order and trade) 
 */
struct FeedHandler {
    FeedHandler();
    ~FeedHandler();
    /// function to process the input message
    void processMessage(char* msg);

    /// function to print all order books
    void printCurrentOrderBook(std::ostream& os) const;

    /// function to dump error summary
    void printErrorSummary(std::ostream& os) const;

 private:
    // function to process an order message
    void processOrder(const feed_order& order);
    // function to process a trade message
    void processTrade(const feed_trade& trade);
    typedef boost::shared_ptr<OrderBook> OrderBookPtr;
    typedef boost::unordered_map<uint32_t, OrderBookPtr> OrderBookMap_t;
    OrderBookMap_t m_orderBookMap;
};

}  // namespace cs
