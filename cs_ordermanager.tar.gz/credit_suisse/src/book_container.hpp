// Copyright (C) 2016 by RajatGirotra
#pragma once

#include "resting_order.hpp"
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/tag.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/hashed_index.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/composite_key.hpp>
#include <functional>

using namespace boost::multi_index;

namespace cs {
    struct by_orderid {};
    struct by_bid_price_time {};
    struct by_ask_price_time {};
    /** \typedef defines a cache to hold resting orders.
     */
    typedef boost::multi_index_container<RestingOrder,
        indexed_by <
            hashed_unique<tag<by_orderid>,
                BOOST_MULTI_INDEX_MEMBER(RestingOrder, uint32_t, m_orderid)>,
            ordered_unique<tag<by_bid_price_time>,
                composite_key<RestingOrder,
                    BOOST_MULTI_INDEX_MEMBER(RestingOrder, double, m_px),
                    BOOST_MULTI_INDEX_MEMBER(RestingOrder, uint64_t, m_nanos)>,
                composite_key_compare<
                    std::greater<double>, std::less<uint64_t> >
                >,
            ordered_unique<tag<by_ask_price_time>,
                composite_key<RestingOrder,
                    BOOST_MULTI_INDEX_MEMBER(RestingOrder, double, m_px),
                    BOOST_MULTI_INDEX_MEMBER(RestingOrder, uint64_t, m_nanos)>,
                composite_key_compare<
                    std::less<double>, std::less<uint64_t> >
                >
            >
        > BOOK_HOLDER_T;

}  // namespace cs
