// Copyright (C) 2016 by RajatGirotra
#include "../errors.hpp"
#include "../feed_handler.hpp"
#include <gtest/gtest.h>
#include <boost/shared_ptr.hpp>
#include <iostream>
#include <cstring>
#include <sstream>
using namespace testing;
using namespace cs;

class OrderManagerTest : public ::testing::Test {
 public:
    OrderManagerTest() {}

    virtual void SetUp() {
        feed_handler.reset(new FeedHandler());
    }

    virtual void TearDown() {
        // print error summary will reset error counts
        feed_handler->printErrorSummary(error_summary);
        error_summary.str("");
        feed_handler.reset();
    }

    ~OrderManagerTest() {
    }
 protected:
    boost::shared_ptr<FeedHandler> feed_handler;
    std::ostringstream error_summary;
};

TEST_F(OrderManagerTest, CorruptMsgsAreCaught) {
    // send a corrupted message and check that it is caught
    // unknow action 'A'
    char msg[100] {};
    strcpy(msg, "A,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    // missing action
    strcpy(msg, "1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    ASSERT_EQ(cs::feed_errors::corrupted_msg.count(), 2);
}

TEST_F(OrderManagerTest, DuplicateOrderIdsAreCaught) {
    // Insert the same order three times.
    // It should only be accepted once
    char msg[100] {};
    strcpy(msg, "N,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 1\n100.5 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
    ASSERT_EQ(cs::feed_errors::duplicate_id.count(), 2);
}

TEST_F(OrderManagerTest, UnexpectedTradesAreCaught) {
    // Send a trade even when the order book is not crossed.
    char msg[100] {};
    strcpy(msg, "N,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,101,S,10,101");
    feed_handler->processMessage(msg);
    strcpy(msg, "X,1,5,100.5");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 1\n101 S 10 \n100.5 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
    ASSERT_EQ(cs::feed_errors::trade_with_no_order.count(), 1);
}

TEST_F(OrderManagerTest, NewOrderNotAcceptedAfterBookIsCrossed) {
    // Make the order book crossing and then send a new order.
    // the new order should not be accepted and should be caught
    char msg[100] {};
    strcpy(msg, "N,1,100,B,10,100.5");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,101,S,4,100");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,102,S,4,100");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 1\n100 S 4 \n100.5 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
    ASSERT_EQ(cs::feed_errors::crossed_book_no_trades.count(), 1);
}

TEST_F(OrderManagerTest, InvalidProductIdsAreCaught) {
    // send orders with incorrect Product Ids
    char msg[100] {};
    strcpy(msg, "N,-1,100,B,10,1000.5");  // negative product id
    feed_handler->processMessage(msg);
    strcpy(msg, "N,0,101,S,4,1001");  // product id 0
    feed_handler->processMessage(msg);
    ASSERT_EQ(cs::feed_errors::invalid_product_id.count(), 2);
}

TEST_F(OrderManagerTest, InvalidPricesAreCaught) {
    // send orders with zero or negative prices
    char msg[100] {};
    strcpy(msg, "N,1,100,B,10,-1000.5");  // negative price
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,101,S,4,0");  // zero price
    feed_handler->processMessage(msg);
    ASSERT_EQ(cs::feed_errors::invalid_price.count(), 2);
}

TEST_F(OrderManagerTest, InvalidQuantitiesAreCaught) {
    // send orders with zero or negative quantity
    char msg[100] {};
    strcpy(msg, "N,1,100,B,-10,1000.5");  // negative qty
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,101,S,0,1001");  // zero qty
    feed_handler->processMessage(msg);
    ASSERT_EQ(cs::feed_errors::invalid_qty.count(), 2);
}

TEST_F(OrderManagerTest, InvalidOrderIdsAreCaught) {
    // send orders with zero or negative order id
    char msg[100] {};
    strcpy(msg, "N,1,-100,B,10,1000.5");  // negative order id
    feed_handler->processMessage(msg);
    strcpy(msg, "N,1,0,S,0,1001");  // zero orderid
    feed_handler->processMessage(msg);
    ASSERT_EQ(cs::feed_errors::invalid_order_id.count(), 2);
}

TEST_F(OrderManagerTest, ValidateThatOrderBookIsCorrectlyFormed) {
    // validate that order book is correctly formed.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,1,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,B,9,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,B,30,975");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,10,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100004,B,10,950");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100005,S,2,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100006,B,1,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "R,5,100004,B,10,950");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100007,S,5,1025");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1025 S 2 S 5 \n1050 S 10 \n1075 S 1 \n1000 B 9 B 1 \n975 B 30 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
    ASSERT_EQ(cs::feed_errors::invalid_order_id.count(), 0);
}

TEST_F(OrderManagerTest, ValidateThatOrderManagerCanCopeWithBadData) {
    // validate that order book is correctly formed.
    char msg[100] {};
    strcpy(msg, ",,,");  // empty data
    feed_handler->processMessage(msg);
    strcpy(msg, "NNN");  // bad record
    feed_handler->processMessage(msg);
    strcpy(msg, "N,123,A,9,100,1");  // invalid format
    feed_handler->processMessage(msg);
    strcpy(msg, "F,-123,A,9,100,1");  // unknow action
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,1000,Q,10,3.55");  // Unknown side
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,1000,S,10,3.55"); // valid record
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n3.55 S 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

TEST_F(OrderManagerTest, ValidateThatModifiesCorrectlyModifiesOrderBook) {
    // validate that order book is correctly formed after order modifies.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,1,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,B,9,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,B,30,975");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,10,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100004,B,10,950");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100005,S,2,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100006,B,1,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100007,S,5,1025");
    feed_handler->processMessage(msg);
    // Modify a few orders now
    strcpy(msg, "M,5,100001,B,2,975");
    feed_handler->processMessage(msg);
    strcpy(msg, "M,5,100007,S,8,975");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1025 S 2 S 8 \n1050 S 10 \n1075 S 1 \n1000 B 2 B 1 \n975 B 30 \n950 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

TEST_F(OrderManagerTest, ValidateThatGivenExampleInExercise) {
    // validate that order book is correctly formed.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,1,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,B,9,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,B,30,975");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,10,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100004,B,10,950");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100005,S,2,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100006,B,1,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "R,5,100004,B,10,950");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100007,S,5,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100008,B,3,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "X,5,2,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "X,5,1,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "R,5,100008,B,3,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "R,5,100005,S,2,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "M,5,100007,S,4,1025");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1025 S 4 \n1050 S 10 \n1075 S 1 \n1000 B 9 B 1 \n975 B 30 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

TEST_F(OrderManagerTest, TradeRemovesMultiplePriceLevels) {
    // validate that a trade can correctly remove multiple price levels.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,50,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,B,20,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,B,10,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,30,1050");
    feed_handler->processMessage(msg);
    // Cross book now
    strcpy(msg, "N,5,100004,B,60,1100");
    feed_handler->processMessage(msg);
    // send trade
    strcpy(msg, "X,5,30,1100");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1075 S 50 \n1100 B 30 \n1025 B 20 \n1000 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

TEST_F(OrderManagerTest, TradeMatchesOldestOrdersFirst) {
    // validate that orders at the same price are matched in the order they are received.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,50,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,B,20,1025");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,B,10,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,30,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100004,S,60,1050"); // 2nd sell order at the same price
    feed_handler->processMessage(msg);
    // Cross book now
    strcpy(msg, "N,5,100005,B,100,1100");
    feed_handler->processMessage(msg);
    // send trade
    strcpy(msg, "X,5,50,1100");
    feed_handler->processMessage(msg);
    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1050 S 40 \n1075 S 50 \n1100 B 50 \n1025 B 20 \n1000 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

TEST_F(OrderManagerTest, ValidateThatOnlyFivePriceLevelsAreOutput) {
    // validate that orders at the same price are matched in the order they are received.
    char msg[100] {};
    strcpy(msg, "N,5,100000,S,50,1075");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100001,S,40,1100");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100002,S,30,1125");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100003,S,20,1150");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100004,S,10,1175");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100005,S,5,1200");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100006,S,500,1200");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100007,S,1,1100");
    feed_handler->processMessage(msg);

    strcpy(msg, "N,5,100008,B,50,1050");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100009,B,40,1000");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100010,B,30,990");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100011,B,20,900");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100012,B,10,800");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100013,B,5,700");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100014,B,500,700");
    feed_handler->processMessage(msg);
    strcpy(msg, "N,5,100015,B,1,1000");
    feed_handler->processMessage(msg);

    std::ostringstream orderBook;
    feed_handler->printCurrentOrderBook(orderBook);
    std::string expected_book = "OrderBook for productid 5\n1075 S 50 \n1100 S 40 S 1 \n1125 S 30 \n1150 S 20 \n1175 S 10 \n1050 B 50 \n1000 B 40 B 1 \n990 B 30 \n900 B 20 \n800 B 10 \n\n";
    EXPECT_EQ(expected_book, orderBook.str());
}

int main(int argc, char* argv[]) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
