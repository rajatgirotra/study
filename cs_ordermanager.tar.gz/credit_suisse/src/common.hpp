// Copyright (C) 2016 by RajatGirotra
#pragma once

#include <cstdint>
namespace cs {

/** Enum to represent the Side on an incoming order or trade message
 */
enum struct Side {
    BID = 0,
    ASK = 1
};

/** Represents the structure of an incoming exchange order.
 */
struct feed_order {
    char m_action;   ///< New (N), Modify(M), or Remove (R)
    uint32_t m_productid;   ///< product id
    uint32_t m_orderid;   ///< order id
    Side m_side;   ///< Side - Buy or Sell
    uint32_t m_qty;   ///< quantity on the order
    double m_px;   ///< price on the order
    uint64_t m_nanos;   ///< time when order is received.

    feed_order() = default;  ///< default c'tor
    feed_order(char act, uint32_t prdid, uint32_t id, Side side, uint32_t qty,
               double px, uint64_t nanos) : m_action(act), m_productid(prdid),
                                            m_orderid(id), m_side(side),
                                            m_qty(qty), m_px(px), m_nanos(nanos)
    {}
};

/** Represents the structure of an incoming exchange trade.
 */
struct feed_trade {
    uint32_t m_productid;  ///< product id
    uint32_t m_qty;   ///< quantity on the trade
    double m_px;   ///< price on the trade
    uint64_t m_nanos;   ///< time when trade is received.

    feed_trade() = default;  ///< default c'tor
    feed_trade(uint32_t prdid, uint32_t qty, double px, uint64_t nanos) :
        m_productid(prdid), m_qty(qty), m_px(px), m_nanos(nanos) {}
};
    
}  // namespace cs
