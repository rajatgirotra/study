// Copyright (C) 2016 by RajatGirotra
#include "order_book.hpp"
#include "errors.hpp"
#include <iostream>
#include <string>
#include <utility>
#include <type_traits>
#include <algorithm>
#include <limits>
#include <functional>
using namespace cs::feed_errors;

namespace {
    /// maximum levels of the order book to be output
    static const size_t max_levels = 5;

    /// helper function to print order book.
    template <typename Iter>
    void printHelper(std::ostream& os, Iter& s_iter, Iter& e_iter) {
        double old_price = 0.0;
        size_t level = 0;
        while (level < max_levels && s_iter != e_iter) {
            const auto& order = *s_iter;
            if (order.m_px != old_price) {
                os << "\n" << order.m_px << " ";
                old_price = order.m_px;
                ++level;
            }
            os << (order.m_side == cs::Side::BID ? 'B' : 'S') << " ";
            os << order.m_qty << " ";
            ++s_iter;
        }
    }

    struct BuyComp : public std::binary_function<double, double, bool> {
        bool operator() (const double& order_price, const double& trade_price) {
            return (order_price >= trade_price);
        }
    };
    struct SellComp : public std::binary_function<double, double, bool> {
        bool operator() (const double& order_price, const double& trade_price) {
            return (order_price <= trade_price);
        }
    };

    /// helper function to match trades
    template <typename Index, typename CompFunc>
    void matchHelper(uint32_t trade_qty, double trade_px, Index& index, CompFunc func,
                     boost::unordered_set<uint32_t>& filledOrders) {
        auto iter = index.begin();
        while (true) {
            // if trade qty is reduced to 0 or we have reach the end of orders, bail out
            if (trade_qty == 0 || iter == index.end())
                break;
            // if we can't trade this price level, exit
            if (!func(iter->m_px, trade_px))
                return;
            // is order fully filled??
            if (iter->m_qty <= trade_qty) {
                // order is fully filled, add order id to fill list
                filledOrders.insert(iter->m_orderid);
                // reduce traded qty
                trade_qty -= iter->m_qty;
                // erase order from order book.
                iter = index.erase(iter);
            } else {
                // partial fill.
                index.modify(iter, [&trade_qty] (cs::RestingOrder& ro) {
                    ro.m_qty -= trade_qty;
                    trade_qty = 0;
                });
            }
        }
    }
}  // namespace

namespace cs {
    OrderBook::OrderBook(const uint32_t& pid, const uint32_t& oid) :
        m_productid(pid), m_currentid(oid),
        m_recentPx(0.0), m_recentQty(0) {
        m_tobPx[0] = std::numeric_limits<double>::min();
        m_tobPx[1] = std::numeric_limits<double>::max();
    }

    void OrderBook::handleOrderAdd(const feed_order& msg) {
        // perform sanity check before proceeding
        if (!sanityCheck(msg)) {
            return;
        }
        // insert the trade in the order book.
        int side = static_cast<std::underlying_type<Side>::type>(msg.m_side);
        book[side].emplace(msg.m_productid, msg.m_orderid,
                           msg.m_side, msg.m_qty, msg.m_px, msg.m_nanos);
        // check top of book BID/ASK to see if book is crossed after insertion
        if (msg.m_side == Side::BID) {
            if (m_tobPx[0] < msg.m_px)
                m_tobPx[0] = msg.m_px;
        } else {
            if (m_tobPx[1] > msg.m_px)
                m_tobPx[1] = msg.m_px;
        }
    }

    void OrderBook::handleOrderModify(const feed_order& msg) {
        // If the order book is crossed, a trade message is expected.
        if (isCrossed()) {
            ++crossed_book_no_trades;
            return;
        }
        // Find order
        int side = static_cast<std::underlying_type<Side>::type>(msg.m_side);
        auto iter = book[side].find(msg.m_orderid);
        if (iter == book[side].end()) {
            // order not found
            ++invalid_order_id;
            return;
        }

        // modify order qty here, please read ASSUMPTIONS file.
        book[side].modify(iter, [msg] (RestingOrder& ro) {
                ro.m_qty = msg.m_qty;
            });
    }

    void OrderBook::handleOrderDelete(const feed_order& msg) {
        // If the order book is crossed, a trade message is expected.
        if (isCrossed()) {
            ++crossed_book_no_trades;
            return;
        }
        // Is order fully filled?
        auto filledIter = m_filledIds.find(msg.m_orderid);
        if (filledIter != m_filledIds.end()) {
            m_filledIds.erase(filledIter);
            return;
        }
        // Find order
        int side = static_cast<std::underlying_type<Side>::type>(msg.m_side);
        auto iter = book[side].find(msg.m_orderid);
        if (iter == book[side].end()) {
            // order not found
            ++invalid_order_id;
            return;
        }
        // Delete order
        book[side].erase(iter);
        return;
    }

    void OrderBook::handleTrade(const feed_trade& msg) {
        // if order book is not crossed, trade is not expected.
        if (!isCrossed()) {
            ++trade_with_no_order;
            return;
        }
        // match trades and remove fully filled trades from order book
        matchTrade(msg);
        // print total quantity traded at the most recent price.
        m_recentPx = msg.m_px;
        m_recentQty = ((msg.m_px != m_recentPx) ? msg.m_qty : m_recentQty + msg.m_qty);
        std::cout << "X," << m_productid << "," << msg.m_qty << "," << msg.m_px << " ==> product " << m_productid << ": " << m_recentQty << "@" << m_recentPx << "\n";
        checkTopOfBook();
    }

    void OrderBook::printCurrentOrderBook(std::ostream& os) const {
        os << "OrderBook for productid " << m_productid;
        // print sell side order book followed by buy side order book
        const auto& sell_index = book[1].get<by_ask_price_time>();
        if (!sell_index.empty()) {
            auto s_iter = sell_index.begin();
            auto e_iter = sell_index.end();
            printHelper(os, s_iter, e_iter);
        }
        const auto& buy_index = book[0].get<by_bid_price_time>();
        if (!buy_index.empty()) {
            auto s_iter = buy_index.begin();
            auto e_iter = buy_index.end();
            printHelper(os, s_iter, e_iter);
        }
        os << "\n\n";
    }

    void OrderBook::checkTopOfBook() {
        const auto& buy_index = book[0].get<by_bid_price_time>();
        if (!buy_index.empty()) {
            auto iter = buy_index.begin();
            m_tobPx[0] = (*iter).m_px;
        } else {
            m_tobPx[0] = std::numeric_limits<double>::min();
        }
        const auto& sell_index = book[1].get<by_ask_price_time>();
        if (!sell_index.empty()) {
            auto iter = sell_index.begin();
            m_tobPx[1] = (*iter).m_px;
        } else {
            m_tobPx[1] = std::numeric_limits<double>::max();
        }
    }

    bool OrderBook::sanityCheck(const feed_order& msg) {
        // If the order book is crossed, a trade message is expected.
        if (isCrossed()) {
            ++crossed_book_no_trades;
            return false;
        }
        // is orderid duplicate?
        int side = static_cast<std::underlying_type<Side>::type>(msg.m_side);
        auto iter = book[side].find(msg.m_orderid);
        if (iter != book[side].end()) {
            ++duplicate_id;  // duplicate orderid
            return false;
        }
        // is orderid sequence correct or out of bound
        if (m_currentid != msg.m_orderid) {
            ++invalid_order_id;
            return false;
        }
        ++m_currentid;
        return true;
    }

    void OrderBook::matchTrade(const feed_trade& msg) {
        // match buys
        auto& buy_index = book[0].get<by_bid_price_time>();
        matchHelper(msg.m_qty, msg.m_px, buy_index, BuyComp(), m_filledIds);
        // match sells
        auto& sell_index = book[1].get<by_ask_price_time>();
        matchHelper(msg.m_qty, msg.m_px, sell_index, SellComp(), m_filledIds);
    }
}  // namespace cs
