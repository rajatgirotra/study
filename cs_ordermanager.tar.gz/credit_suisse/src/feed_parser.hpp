// Copyright (C) 2016 by RajatGirotra
#pragma once

#include "common.hpp"
#include <string>
#include <utility>

namespace cs {
/** Feed parser helper function.
 * This function parses the input string representing an order
 * and returns a feed_order object
 */
std::pair<bool, feed_order> parseOrder(char action, char* msg);

/** Feed parser helper function.
 * This function parses the input string representing a trade
 * and returns a feed_trade object
 */
std::pair<bool, feed_trade> parseTrade(char* msg);
}  // namespace cs
    
