// Copyright (C) 2016 by RajatGirotra
#pragma once

#include "book_container.hpp"
#include "common.hpp"
#include <boost/unordered_set.hpp>
#include <string>
#include <cstdint>
#include <fstream>

namespace cs {
class OrderBook {
 public:
    /// constructor - takes the product id of this order book and the starting orderid sequence.
    OrderBook(const uint32_t& pid, const uint32_t& oid);

    /// do not allow OrderBook to be copied.
    OrderBook(const OrderBook&) = delete;
    OrderBook& operator = (const OrderBook&) = delete;

    /// handler for new incoming order
    void handleOrderAdd(const feed_order& msg);

    /// handler for order modification
    void handleOrderModify(const feed_order& msg);

    /// handler for order deletion
    void handleOrderDelete(const feed_order& msg);

    /// hander for incoming executions
    void handleTrade(const feed_trade& msg);

    /// print the current order book
    void printCurrentOrderBook(std::ostream& os) const;

 private:
    /// return true if book is crossed.
    inline bool isCrossed() const { return m_tobPx[0] >= m_tobPx[1]; }

    /// check top of book level and if book is crossed, mark it.
    void checkTopOfBook();

    /// sanity check
    bool sanityCheck(const feed_order& msg);

    /// function to match incoming trade and modifying the order book
    void matchTrade(const feed_trade& trade_msg);

    /// ProductId of this order book
    uint32_t m_productid;

    /** OrderBook holder
     * index 0 will hold buy side orders
     * index 1 will hold sell side orders
     */
    BOOK_HOLDER_T book[2];

    /// top of book buy and sell px
    double m_tobPx[2];

    /// sequence of order id's for this order book
    uint32_t m_currentid;

    /// set of orderids that are fully filled
    boost::unordered_set<uint32_t> m_filledIds;

    /// recent trade price and quantity
    double m_recentPx;
    uint32_t m_recentQty;
};

}  // namespace cs
