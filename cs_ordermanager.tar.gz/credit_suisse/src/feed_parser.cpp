// Copyright (C) 2016 by RajatGirotra
#include "feed_parser.hpp"
#include "common.hpp"
#include "errors.hpp"
#include <string>
#include <cstring>
#include <cstdint>
#include <chrono>

using namespace cs::feed_errors;
namespace {

bool get_product_id(char* msg, const char* delim, uint32_t* productid) {
    char* token = strtok(msg, delim);
    if (!token) {
        // missing product id
        ++invalid_product_id;
        return false;
    }
    auto id = atoi(token);
    if (id <= 0) {
        // Negative/invalid product id
        ++invalid_product_id;
        return false;
    }
    *productid = id;
    return true;
}

bool get_order_id(char* msg, const char* delim, uint32_t* orderid) {
    char* token = strtok(msg, delim);
    if (!token) {
        // missing orderid
        ++invalid_order_id;
        return false;
    }
    auto id = atoi(token);
    if (id <= 0) {
        // Negative/invalid order id
        ++invalid_order_id;
        return false;
    }
    *orderid = id;
    return true;
}

bool get_qty(char* msg, const char* delim, uint32_t* qty) {
    char* token = strtok(msg, delim);
    if (!token) {
        // missing qty
        ++invalid_qty;
        return false;
    }
    auto quantity = atoi(token);
    if (quantity <= 0) {
        // Negative/invalid quantity
        ++invalid_qty;
        return false;
    }
    *qty = quantity;
    return true;
}

bool get_px(char* msg, const char* delim, double* px) {
    char* token = strtok(msg, delim);
    if (!token) {
        // missing price
        ++invalid_price;
        return false;
    }
    auto price = strtod(token, nullptr);
    if (price <= 0) {
        // Negative/invalid price
        ++invalid_price;
        return false;
    }
    *px = price;
    return true;
}

bool get_side(char* msg, const char* delim, cs::Side* side) {
    char* token = strtok(msg, delim);
    if (!token) {
        // missing side
        ++corrupted_msg;
        return false;
    }
    if (*token != 'B' && *token != 'S') {
        ++invalid_side;
        return false;
    }
    *side = ((*token == 'B') ? cs::Side::BID : cs::Side::ASK);
    return true;
}
}  // namespace

namespace cs {
std::pair<bool, feed_order> parseOrder(char action, char* msg) {
    feed_order order {};
    static const char* delim = ",";
    order.m_action = action;
    char* token = strtok(msg, delim);  // skip action field
    switch (action) {
        case 'N':  // delibrate fallthru
        case 'M':  // delibrate fallthru
        case 'R': {
            if (!get_product_id(nullptr, delim, &order.m_productid))
                return std::make_pair(false, order);
            if (!get_order_id(nullptr, delim, &order.m_orderid))
                return std::make_pair(false, order);
            if (!get_side(nullptr, delim, &order.m_side))
                return std::make_pair(false, order);
            if (!get_qty(nullptr, delim, &order.m_qty))
                return std::make_pair(false, order);
            if (!get_px(nullptr, delim, &order.m_px))
                return std::make_pair(false, order);
            break;
        }
        default: {
            ++corrupted_msg;
            return std::make_pair(false, order);
        }
    }
    order.m_nanos = std::chrono::steady_clock::now().time_since_epoch().count();
    return std::make_pair(true, order);
}

std::pair<bool, feed_trade> parseTrade(char* msg) {
    feed_trade trade {};
    static const char* delim = ",";
    char* token = strtok(msg, delim);  // skip action field
    if (!get_product_id(nullptr, delim, &trade.m_productid))
        return std::make_pair(false, trade);
    if (!get_qty(nullptr, delim, &trade.m_qty))
        return std::make_pair(false, trade);
    if (!get_px(nullptr, delim, &trade.m_px))
        return std::make_pair(false, trade);
    trade.m_nanos = std::chrono::steady_clock::now().time_since_epoch().count();
    return std::make_pair(true, trade);
}

}  // namespace cs
