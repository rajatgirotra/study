// Copyright (C) 2016 by RajatGirotra
#include "errors.hpp"

namespace cs { namespace feed_errors {
error_counter<Errors::CORRUPTED_MSG> corrupted_msg("Corrupted Messages: ");
error_counter<Errors::DUPLICATE_ORDER_ID> duplicate_id("Duplicate Messages: ");
error_counter<Errors::TRADES_WITH_NO_ORDER> trade_with_no_order("Trades with no orders: ");
error_counter<Errors::REMOVE_WITH_NO_ORDER> remove_with_no_order("Removes with no orders: ");
error_counter<Errors::CROSSED_BOOK_NO_TRADES> crossed_book_no_trades("Crossed Book but no trades:");
error_counter<Errors::INVALID_ORDER_ID> invalid_order_id("Invalid/Missing/Negative OrderIds: ");
error_counter<Errors::INVALID_PRICE> invalid_price("Invalid/Missing/Negative Prices: ");
error_counter<Errors::INVALID_QTY> invalid_qty("Invalid/Missing/Negative Qtys: ");
error_counter<Errors::INVALID_PRODUCT_ID> invalid_product_id("Invalid/Missing/Negative Product Id: ");
error_counter<Errors::INVALID_SIDE> invalid_side("Invalid side: ");

std::tuple<error_counter<Errors::CORRUPTED_MSG>&,
           error_counter<Errors::DUPLICATE_ORDER_ID>&,
           error_counter<Errors::TRADES_WITH_NO_ORDER>&,
           error_counter<Errors::REMOVE_WITH_NO_ORDER>&,
           error_counter<Errors::CROSSED_BOOK_NO_TRADES>&,
           error_counter<Errors::INVALID_ORDER_ID>&,
           error_counter<Errors::INVALID_PRICE>&,
           error_counter<Errors::INVALID_QTY>&,
           error_counter<Errors::INVALID_PRODUCT_ID>&,
           error_counter<Errors::INVALID_SIDE>&
           > errors(corrupted_msg, duplicate_id, trade_with_no_order,
                    remove_with_no_order, crossed_book_no_trades,
                    invalid_order_id, invalid_price, invalid_qty,
                    invalid_product_id, invalid_side);
}  // namespace feed_errors
}  // namespace cs
