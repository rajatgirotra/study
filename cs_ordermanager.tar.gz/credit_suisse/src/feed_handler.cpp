// Copyright (C) 2016 by RajatGirotra

#include "feed_handler.hpp"
#include "order_book.hpp"
#include "common.hpp"
#include "errors.hpp"
#include "feed_parser.hpp"
#include <boost/fusion/adapted.hpp>
#include <boost/fusion/algorithm.hpp>
#include <string>
#include <tuple>

#include <iostream>

namespace {
/// Helper function to print error name and count.
struct print_summary {
 private:
    std::ostream& os;
 public:
    explicit print_summary(std::ostream& o) : os(o) {}
    template <typename T>
    void operator() (const T& ec) const {
        os << "\t" << ec.name() << " "
           << ec.count() << "\n";
    }
};

/** helper function to clear error counts
  needed only while running automated tests.
 */
struct clear_summary {
 public:
    template <typename T>
    void operator() (const T& ec) const {
        auto& ec_nc = const_cast<T&>(ec);
        ec_nc.reset();
    }
};
}  // namespace

using namespace cs::feed_errors;
namespace cs {

FeedHandler::FeedHandler() {}
FeedHandler::~FeedHandler() {}

void FeedHandler::processMessage(char* msg) {
    char action = msg[0];
    if (action == 'X') {
        // execution message
        auto parse_result = parseTrade(msg);
        if (!parse_result.first)
            return;  // nothing to do.
        processTrade(parse_result.second);
    } else {
        // Order message
        auto parse_result = parseOrder(action, msg);
        if (!parse_result.first)
            return;  // nothing to do
        processOrder(parse_result.second);
    }
}

void FeedHandler::processTrade(const feed_trade& trade) {
    auto iter = m_orderBookMap.find(trade.m_productid);
    if (iter == m_orderBookMap.end()) {
        ++invalid_product_id;  // invalid product id
        return;
    }
    iter->second->handleTrade(trade);
}
void FeedHandler::processOrder(const feed_order& order) {
    switch (order.m_action) {
      case 'N': {
          boost::shared_ptr<OrderBook> order_book {};
          auto iter = m_orderBookMap.find(order.m_productid);
          if (iter == m_orderBookMap.end()) {
              // product id received for first time
              order_book = boost::shared_ptr<OrderBook>(
                  new OrderBook(order.m_productid, order.m_orderid));
              m_orderBookMap[order.m_productid] = order_book;
          } else {
              order_book = iter->second;
          }
          order_book->handleOrderAdd(order);
          break;
      }
      case 'M': {
          auto iter = m_orderBookMap.find(order.m_productid);
          if (iter == m_orderBookMap.end()) {
              // trade modified received with unknown product id
              ++invalid_product_id;
              return;
          }
          iter->second->handleOrderModify(order);
          break;
      }
      case 'R': {
          auto iter = m_orderBookMap.find(order.m_productid);
          if (iter == m_orderBookMap.end()) {
              // trade cancel request received with unknown product id
              ++invalid_product_id;
              return;
          }
          iter->second->handleOrderDelete(order);
          break;
      }
      default: {
          // unknown message type
          ++corrupted_msg;
          break;
      }
    }
}

void FeedHandler::printCurrentOrderBook(std::ostream& os) const {
    // Iterate m_orderBookMap and print order book for each ProductId
    for (const auto& item : m_orderBookMap) {
        item.second->printCurrentOrderBook(os);
    }
}

void FeedHandler::printErrorSummary(std::ostream& os) const {
    os << "Summary Of Errors" << std::endl;
    boost::fusion::for_each(errors, print_summary(os));
    os.flush();
    // clear error summary, needed for running automated tests
    boost::fusion::for_each(errors, clear_summary());
}
}  // namespace cs

