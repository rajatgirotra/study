var searchData=
[
  ['shapetraits',['ShapeTraits',['../structShapeTraits.html#ae83a1439cb5be08a9fcff38a94b5813a',1,'ShapeTraits::ShapeTraits(Shape shape)'],['../structShapeTraits.html#a916abb4f87ce3c79772594bb80fb96fc',1,'ShapeTraits::ShapeTraits()']]]
];
