var searchData=
[
  ['m_5fblock',['m_block',['../structShapeTraits.html#ad52a36ddcc804f34b1e398540499628d',1,'ShapeTraits']]],
  ['m_5fshape',['m_shape',['../structShapeTraits.html#ac3fce45cd44b11e99adefbeb9efd6211',1,'ShapeTraits']]]
];
