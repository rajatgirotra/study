var searchData=
[
  ['shapetraits',['ShapeTraits',['../structShapeTraits.html',1,'']]]
];
