var searchData=
[
  ['getheight',['getHeight',['../classTetrisGrid.html#acd31d8af2cfe48fbfd0323c33099795e',1,'TetrisGrid']]],
  ['getshape',['getShape',['../structShapeTraits.html#a6c0e90a28dd3d07b67ea0974faa3c4e0',1,'ShapeTraits']]]
];
