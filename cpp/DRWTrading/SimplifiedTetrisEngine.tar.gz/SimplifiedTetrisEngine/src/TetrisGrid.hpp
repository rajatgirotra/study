#ifndef _TETRIS_GRID_HPP_
#define _TETRIS_GRID_HPP_

#include <bitset>
#include <array> //C++11 array
#include <iostream>

using std::bitset;
using std::array;
using std::ostream;

/** Tetris Grid class representing the playing grid.
 *  It is given that the grid is 10 units wide and the maximum height can be 100.\n
 *  So we can use a 10*100 matrix to represent a grid.\n
 *  Each element(cell) is the grid is a unit square.\n
 *  A zero represents that the cell is empty.\n
 *  A one represents that the cell is filled.\n
 */
class TetrisGrid
{
    private:
        array<short, 12> m_col_height; ///< The height of individual columns in the grid.

        /** Representation of the grid using bitset (most compact)
         *  The bottom-most row in the grid will be index = 0.
         */
        array<bitset<12>, 100> m_grid;

        /** doDrawShape function. Given the new shape and the drop index,
         * it calculates the position where the shape should be drawn on the grid. Called by drawShape().
         *
         * \param letter a character identifier for the shape
         * \param drop_index an integer identifier of the left most index on the grid where the shape is dropped.
         * \param shape_Y an output parameter specifying the Y coordinate where the shape must be drawn
         * \sa drawshape()
         */
        void doDrawShape(char letter, int drop_index, int& shape_Y);

        /**
         * function to remove complete lines after each shape is drawn to the grid.
         */
        void removeLines();

    public:
        /** Tetris Grid default constructor
         *  The default c'tor creates an empty grid.
         */
        TetrisGrid();

        /** helper function to print the grid.
         */
        void printGrid() const;

        /** Function to draw a new shape in the grid
         *  This is the main function where all processing starts. Is called from main.cpp
         *  \param letter a character identifying the shape to be drawn on the grid.
         *  \param drop_index an integer specifying the left most index where the shape is dropped.
         */
        void drawShape(char letter, int drop_index);

        /** Function to get the grid height
         */
        short getHeight() const;
};


#endif // _TETRIS_GRID_HPP_
