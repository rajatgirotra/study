#include "ShapeTraits.hpp"
#include <cassert>
#include <iostream>
#include <algorithm>

using std::bitset;
using std::cout;
using std::cerr;
using std::endl;
using std::array;

/* Definition of our shape objects */
ShapeTraits Shape_Q(Shape::Q);
ShapeTraits Shape_Z(Shape::Z);
ShapeTraits Shape_S(Shape::S);
ShapeTraits Shape_T(Shape::T);
ShapeTraits Shape_I(Shape::I);
ShapeTraits Shape_L(Shape::L);
ShapeTraits Shape_J(Shape::J);


//Ctor. Based on the shape argument, we set bits in matrix accordingly.
//The best way is to use a helper function (printShape()) provided below to see how a matrix
//represents a shape.
ShapeTraits::ShapeTraits(Shape arg) : m_shape(arg)
{
    switch(m_shape)
    {
        case Shape::Q : { m_block[0].set(2).set(3); m_block[1].set(2).set(3); break; }
        case Shape::Z : { m_block[0].set(1).set(2); m_block[1].set(2).set(3); break; }
        case Shape::S : { m_block[0].set(2).set(3); m_block[1].set(1).set(2); break; }
        case Shape::T : { m_block[0].set(2); m_block[1].set(1).set(2).set(3); break; }
        case Shape::I : { m_block[0].set(0).set(1).set(2).set(3); break; }
        case Shape::L : { m_block[0].set(2).set(3); m_block[1].set(3); m_block[2].set(3);break; }
        case Shape::J : { m_block[0].set(2).set(3); m_block[1].set(2); m_block[2].set(2);break; }
        default: { cerr << "Trying to initialize un-recognized Shape.. exiting"; assert(false); }
    }
}

//Helper function to print a shape.
void ShapeTraits::printShape() const
{
    switch(this->m_shape)
    {
        case Shape::Q : { cout << "\nShape Q\n"; break; }
        case Shape::Z : { cout << "\nShape Z\n"; break; }
        case Shape::S : { cout << "\nShape S\n"; break; }
        case Shape::T : { cout << "\nShape T\n"; break; }
        case Shape::I : { cout << "\nShape I\n"; break; }
        case Shape::L : { cout << "\nShape L\n"; break; }
        case Shape::J : { cout << "\nShape J\n"; break; }
    }
  
    std::for_each(m_block.rbegin(), m_block.rend(), [](const bitset<4>& bs) {
            cout << bs << endl;
    });
}

//Get object based on character 
ShapeTraits& ShapeTraits::getShape(char letter)
{
    switch(letter)
    {
        case 'Q' : return Shape_Q;
        case 'Z' : return Shape_Z;
        case 'S' : return Shape_S;
        case 'T' : return Shape_T;
        case 'I' : return Shape_I;
        case 'L' : return Shape_L;
        case 'J' : return Shape_J;
        default: cerr << "Invalid input letter: " << letter << endl; assert(false);
    }
}
