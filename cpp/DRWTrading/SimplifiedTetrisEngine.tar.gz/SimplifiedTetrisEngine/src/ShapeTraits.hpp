#ifndef _TETRIS_SHAPE_TRAITS_HPP_
#define _TETRIS_SHAPE_TRAITS_HPP_

#include "Enums.hpp"
#include <bitset>
#include <array> //C++11 array

/** Each shape/block will be represented by a 4*4 matrix.                                                     
  * Each element(cell) in the matrix identifies presence/absence of a unit square.\n                          
  * A zero in the matrix represents that the unit square is absent.\n                                         
  * A one in the matrix represents that a unit square is present.\n                                           
  * Also since the matrix has only 0's or 1's, we use a bitset as an optimization.\n                          
  */         
struct ShapeTraits
{
        Shape m_shape; ///< The unique letter to represent this shape.

        std::array<std::bitset<4>, 4> m_block; ///< The matrix is best represented using a bitset (most compact).

        /** ShapeTraits constructor
         * \param shape the Shape type enum value.
         */
        ShapeTraits(Shape  shape);

        /** Default shape constructor
         */
        ShapeTraits(){};

        /** Helper function to print a shape.
         *  Prints the shape letter and the corresponding matrix representation.
         */
        void printShape() const;

        /** Get ShapeTraits object based on character letter
         */
        static ShapeTraits& getShape(char letter);
};

/** Standard shapes we need to use in our tetris implementation.
  * Declaring extern to avoid code bloat.
  */
extern ShapeTraits Shape_Q;
extern ShapeTraits Shape_Z;
extern ShapeTraits Shape_S;
extern ShapeTraits Shape_T;
extern ShapeTraits Shape_I;
extern ShapeTraits Shape_L;
extern ShapeTraits Shape_J;

#endif // _TETRIS_SHAPE_TRAITS_HPP_
