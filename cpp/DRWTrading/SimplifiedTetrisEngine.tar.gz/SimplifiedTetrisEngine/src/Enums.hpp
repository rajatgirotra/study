#ifndef _TETRIS_ENUMS_HPP_
#define _TETRIS_ENUMS_HPP_

/** Shape enum. Each shape/block is identified by a letter.
 */
enum class Shape : char
{
    Q = 'Q',
    Z = 'Z',
    S = 'S',
    T = 'T',
    I = 'I',
    L = 'L',
    J = 'J'
};

#endif // _TETRIS_ENUMS_HPP_

