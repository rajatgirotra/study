#include "TetrisGrid.hpp"
#include <iostream>
#include <algorithm>
#include <functional>
#include <string>
#include "ShapeTraits.hpp"

using std::cout;
using std::cerr;
using std::endl;

//C'tor
TetrisGrid::TetrisGrid()
{
    m_col_height.fill(0); //Default height of all 10 columns is 0
}

void TetrisGrid::printGrid() const
{
    cout << "\nGrid\n";
    std::for_each(m_grid.rbegin() + getHeight() -1, m_grid.rend(), [](const bitset<12>& bs) {
            cout << bs << endl;
    });
}


short TetrisGrid::getHeight() const
{
    return *std::max_element(m_col_height.begin(), m_col_height.end());
}

void TetrisGrid::removeLines()
{
    //We traverse the grid from top to bottom.                                                                
    //Each completed line is replaces by row above it. 
    for(int y_index = getHeight()-1; y_index >=0; --y_index)
    {
        if(m_grid[y_index].count() == 10)
        {
            for(int i = y_index+1; i <= getHeight(); ++i)
                m_grid[i-1] = m_grid[i];

            //Reduce height by one.
            std::transform(m_col_height.begin(), m_col_height.end(), m_col_height.begin(), 
                              [](int i) {
                                  return --i;});
        }
    }
}

void TetrisGrid::drawShape(char letter, int drop_index)
{
    int shape_Yoff = 0;

    //Call doDrawShape; which returns the Y coordinate of the grid
    //where the shape must be drawn
    doDrawShape(letter, drop_index, shape_Yoff);

    //Modify our grid to position the new shape.
    ShapeTraits oShape = ShapeTraits::getShape(letter);
    const array<bitset<4>, 4>& shapeMatrix = oShape.m_block;

    for(int i : {0,1,2,3}) {
        const bitset<4>& bs = shapeMatrix[i];
        for(int j : {3,2,1,0}) {
            if(bs.test(j)) {
                m_grid[shape_Yoff + i].set(11-drop_index-3+j);
                m_col_height[drop_index+3-j] = std::max(shape_Yoff+i+1, (int)(m_col_height[drop_index+3-j]));
            }
        }
    }

    //The shape has been drawn. Simply remove all complete lines now.
    removeLines();
}

void TetrisGrid::doDrawShape(char letter, int drop_index, int& shape_Yoff)
{
    shape_Yoff = 0;
    /*
     * Assume valid arguments as advised in the problem. To draw a shape on the grid, we will work on a 
     * smaller snapshot of the grid. This snapshot is a 4*4 matrix which will be fetched based on the 
     * drop_index argument
     */

    //Get the maximum height of the grid, between columns drop_index and drop_index + 3.
    short maxSubGridHeight = 0;
    maxSubGridHeight =   *std::max_element(m_col_height.begin() + drop_index, m_col_height.begin() + drop_index + 4);
    //cout << "maxSubGridHeight: " << maxSubGridHeight << endl;

    //If maxSubGridHeight is 0, our sub grid is empty, and we know straight away the position of our new shape.
    if(maxSubGridHeight == 0)
        return;

    //Get the shape matrix based on argument letter
    ShapeTraits oShape = ShapeTraits::getShape(letter);
    const array<bitset<4>, 4>& shapeMatrix = oShape.m_block;

    /*
     * We have two matrices now. One is our subGrid matrix (4*4) and other is our shapeMatrix (4*4)
     * We compare rows of both matrices in the following order to find the position of our new matrix on the grid
     * Comparison 1: {0,3} --> compare subGrid row 0 with shapeMatrix row 3
     * Comparison 2: {0,2} and {1,3} 
     * Comparison 3: {0,1} and {1,2} and {2,3}
     * Comparison 4: {0,0} and {1,1} and {2,2} and {3,3}
     * The comparison is done using bitwise and operator
     * Also the comparison can be done in for/while loops, However not doing it here
     * to make the code more readable.
     */
    int iterations = 1;
    shape_Yoff =maxSubGridHeight;
    while(iterations <= 4)
    {
        int comparisonNo = iterations;
        short maxHeight = maxSubGridHeight;
        int shape_index = comparisonNo - 1;
        bitset<4> gridSubRow;
        bitset<4> shapeRow;
        while(comparisonNo > 0 && maxHeight > 0)
        {
            shapeRow  = shapeMatrix[shape_index];
            gridSubRow = bitset<4>(m_grid[maxHeight-1].to_string(), drop_index, 4);
            if(shapeRow.to_ulong() & gridSubRow.to_ulong()) //and is non  zero, so we get the y coordinate of our new shape.
                return;
            --comparisonNo; --shape_index; --maxHeight;
        }
        if(comparisonNo > 0 && maxHeight <= 0)
        {
            shape_Yoff = 0;
            return;
        }
        --shape_Yoff;
        ++iterations;
    }
}
