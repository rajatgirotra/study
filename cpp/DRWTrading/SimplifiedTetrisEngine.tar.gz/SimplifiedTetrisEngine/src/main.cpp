#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include "ShapeTraits.hpp"
#include "TetrisGrid.hpp"
using namespace std;

int main(int argc, char* argv[])
{
    //Get fileName as command line argument.
    if(argc != 2)
    {
        cerr << "Usage:\n\tTetrisEngine <inputFileName>\n";
        exit(1);
    }

    //Open input file, If cannot open file, log error and exit.
    ifstream iFile(argv[1]);
    if(!iFile)
    {
        cerr << "Unable to open file [" << argv[1] << "] for reading. Please check file path\n";
        exit(1);
    }

    //Open output.txt file for storing grid heights. If unable to open file, log error and exit.
    ofstream oFile("output.txt");
    if(!oFile)
    {
        cerr << "Unable to open file [output.txt] for writing. Please check\n";
        exit(1);
    }


    char ch, comma; //ch will store the type of Block(Q,Z,S etc..) to be processed next.
    int index; //index of the left most column a block will occupy.
    string inputSeq; //Each line in the input file is fetched and stored here.
    while(iFile)
    {
        std::getline(iFile, inputSeq);
        if(inputSeq.size() > 0)
        {
            istringstream iss(inputSeq);
            //Create a new tetris grid. By default the grid is empty.
            TetrisGrid grid;
            while(iss)
            {
               iss >> ch >> index >> comma;
               grid.drawShape(ch, index);
            }
            //Fetch height. and write to oFile.
            oFile << grid.getHeight() << "\n";
            //grid.printGrid();
        }
    }

    //Close file handles.
    iFile.close();
    oFile.close();

}
