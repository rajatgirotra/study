#!/bin/bash

port=$1
exec 3> /dev/tcp/localhost/${port}
./stream_stock_data.sh 1 static_data_exchange_1 3 ${port} &

exec 4> /dev/tcp/localhost/${port}
./stream_stock_data.sh 2 static_data_exchange_2 4 ${port} &

exec 5> /dev/tcp/localhost/${port}
./stream_stock_data.sh 3 static_data_exchange_3 5 ${port} &

exec 6> /dev/tcp/localhost/${port}
./stream_stock_data.sh 4 static_data_exchange_4 6 ${port} &

exec 7> /dev/tcp/localhost/${port}
./stream_stock_data.sh 5 static_data_exchange_5 7 ${port} &

for job in `jobs -p`
do
    echo "Waiting for $job"
    wait $job
done

# close all tcp file descriptors
exec 3>&-
exec 4>&-
exec 5>&-
exec 6>&-
exec 7>&-
