#!/bin/bash

function stream_stock_data() {
    exchange_number=$1
    file_name=$2
    descriptor=$3
    port=$4

    printf -v exchange_str "%08x" $exchange_number
    exchange=''
    for(( i=0; i < ${#exchange_str}; i+=2 ))
    do
        exchange="${exchange}\x"
        exchange=${exchange}${exchange_str:$i:2}
    done

    for stock in `cat ${file_name}`
    do
        printf -v hex_stock "%016x" $stock;
        str=''
        for(( i=0; i < ${#hex_stock}; i+=2 ))
        do
            str="${str}\x"
            str=${str}${hex_stock:$i:2}
        done
        echo -ne "${exchange}${str}" >&${descriptor}
    done
}

stream_stock_data $1 $2 $3 $4
