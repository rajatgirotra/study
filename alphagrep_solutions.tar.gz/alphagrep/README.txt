BUILDING
========
There is a single Makefile to build all three solutions. Makefile uses gcc compiler which must be C++11 compliant.

'make all' will build all three executables. You can build individual solutions using.

make version_queue
make circular_printer
make fly_sort

'make clean' will remove built dependencies and targets.


RUNNING
=======

Version Queue
-------------

./version_queue 
6
e 1
e 4
d
e 5
p 3
Queue at version 3: 1 
p 4
Queue at version 4: 1 5 


Circular Printer
---------------
./circular_printer 
Usage:
	./circular_printer <string> <char_count> <thread_count> <iterations>

./circular_printer ABCDEFGHIJ 3 4 2
Thread1: ABC
Thread2: DEF
Thread3: GHI
Thread4: JAB
Thread1: CDE
Thread2: FGH
Thread3: IJA
Thread4: BCD


Fly Sort
--------
./fly_sort
Usage
	./fly_sort  <portNo>


To test fly_sort program, I have included stock data files for 5 exchanges (static_data_exchange_1, static_data_exchange_2 and so on.)
Each of these files have 8 byte integers in sorted order. These integers identify stocks traded on that particular exchange.
To stream all this data, a sample bash script is provided called "fly_sort_test.sh" which takes a port_number as argument
and will stream all the integers (from all the exchange files) to the fly_sort server program (along with the exchange number).

First start the server program. Eg:

./fly_sort 7777 > all_stocks

In another terminal, run the test script
./fly_sort_test.sh 7777
