// Copyright (C) 2016 by RajatGirotra

#include <iostream>
#include <array>
#include <deque>
#include <cassert>
#include <algorithm>
#include <iterator>
using std::cin;
using std::cout;
using std::endl;

// Every item in the queue contains a value and the enque version number.
struct Item {
    int value;
    int version;
    explicit Item(const int& pval = 0, const int& pver = 0)
        : value(pval),
          version(pver) {
    }
};

struct Version_Queue {
    std::array<Item, 100> q;
    int q_index;
    int q_version;
    Version_Queue(): q_index(0), q_version(0) {
    }

    void enqueue(const int& val);
    void dequeue();
    void print_q(const int& version) const;
};

void Version_Queue::enqueue(const int& val) {
    ++q_version;  // bump up version
    q[q_index] = Item(val, q_version);  // enqueue
    ++q_index;  // bump up index
}

void Version_Queue::dequeue() {
    ++q_version;  // bump up version
}

void Version_Queue::print_q(const int& version) const {
    std::deque<int> print_q;
    int previous_version {};
    int index {};
    while (index < q_index) {
        const auto& item = q[index];
        if (item.version <= version) {
            for (auto i = item.version-1; i > previous_version;) {
                print_q.pop_back();
                ++previous_version;
            }
            print_q.push_back(item.value);
            previous_version = item.version;
            ++index;
            continue;
        }
        break;
    }
    for (auto i = version; i > previous_version; --i)
        print_q.pop_back();
    cout << "Queue at version " << version << ": ";
    std::copy(print_q.begin(), print_q.end(), std::ostream_iterator<int>(cout, " "));
    cout << "\n";
}

int main(int argc, char* argv[]) {
    int operation_count = 0;
    char operation {};  // shoud be 'e' or 'd' or 'p'
    int value {};
    int print_version {};
    Version_Queue version_q;

    cin >> operation_count;
    for (auto i = 0; i < operation_count; ++i) {
        cin >> operation;
        switch (operation) {
            case 'e': {
                cin >> std::skipws >> value;
                version_q.enqueue(value);
                break;
            }
            case 'd': {
                assert(version_q.q_index != 0);  // invalid operation dequeue on empty queue.
                version_q.dequeue();
                break;
            }
            case 'p': {
                cin >> std::skipws >> print_version;
                assert((print_version <= version_q.q_version) &&
                       (print_version > 0));
                version_q.print_q(print_version);
                break;
            }
            default:
                assert(false);  // invalid operation on queue.
        }
    }
    return 0;
}

