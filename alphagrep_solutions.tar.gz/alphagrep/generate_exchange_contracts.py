import sys
import random


def main():
    exchange_id = sys.argv[1]
    contract_count = int(sys.argv[2])
    random.seed()
    filename = 'static_data_exchange_' + exchange_id
    with open(filename, 'w') as fil:
        for i in range(contract_count):
            fil.write(str(random.randint(1, 18446744073709551615)))  # 2^64 -1
            fil.write('\n')
        fil.write(str('0'))
        fil.write('\n')

if __name__ == "__main__":
    main()
