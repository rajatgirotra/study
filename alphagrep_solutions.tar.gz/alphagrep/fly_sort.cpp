// Copyright (C) 2016 by RajatGirotra

#include <unistd.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>

// number of clients supported simultaneously
#define CLIENTS_COUNT 100

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("%s\n\t%s %s\n", "Usage", argv[0], " <portNo>");
        return -1;
    }

    uint16_t portNo = htons(atoi(argv[1]));
    int server_fd {};
    struct sockaddr_in server_addr;
    uint8_t bytes[13] {};

    // create a server TCP socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        printf("%s", "Could not create server socket");
        return -1;
    }

    // Bind server socket to addr and port
    memset(&server_addr, 0, sizeof(sockaddr_in));
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // any interface is fine
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = portNo;
    if (bind(server_fd, reinterpret_cast<const sockaddr*>(&server_addr),
             sizeof(server_addr)) < 0) {
        printf("%s", "Could not bind server socket");
        return -1;
    }

    if (listen(server_fd, CLIENTS_COUNT) < 0) {
        printf("%s", "Could not listen on server socket");
        return -1;
    }

    int max_fd = server_fd;  // to be used for select.
    // connected file descriptors will go to this array
    int client_fds[CLIENTS_COUNT];
    int client_fd_index = -1;
    for (auto clifd = 0; clifd < CLIENTS_COUNT; ++clifd) {
        client_fds[clifd] = -1;
    }
    fd_set descriptors;
    FD_ZERO(&descriptors);
    FD_SET(server_fd, &descriptors);

    // call select in a loop to constantly poll available descriptors
    while (true) {
        fd_set tmp_fds;
        tmp_fds = descriptors;

        auto ready_descriptors = select(max_fd+1, &tmp_fds, 0, 0, 0);
        // printf("Ready_descriptors %d\n", ready_descriptors);
        if (ready_descriptors < 0) {
            printf("%s\n", "Error/Interrupt occurred during select system call");
            return -1;
        }

        if (FD_ISSET(server_fd, &tmp_fds)) {
            // a new connection is available, so call accept and
            // it should not block
            auto new_fd = accept(server_fd, 0, 0);
            if (new_fd < 0) {
                printf("%s\n", "Error during accepting new client connection");
                return -1;
            }
            // printf("New connection fd %d\n", new_fd);
            // set socket option for low water level to 12 bytes.
            int min_bytes = 12;
            if (setsockopt(new_fd, SOL_SOCKET, SO_RCVLOWAT,
                             static_cast<const void*>(&min_bytes),
                             sizeof(int)) < 0) {
                printf("Could not set low water mark for socket receive buffer to 12 bytes\n");
                return -1;
            }
            // remember new_fd
            for (auto clifd = 0; clifd < CLIENTS_COUNT; ++clifd) {
                if (client_fds[clifd] < 0) {
                    client_fds[clifd] = new_fd;
                    client_fd_index = (clifd > client_fd_index ?
                                       clifd : client_fd_index);
                    break;
                }
            }
            FD_SET(new_fd, &descriptors);
            max_fd = (max_fd < new_fd ? new_fd : max_fd);

            --ready_descriptors;
            // printf("max_fd %d\n", max_fd);
            // printf("client_fd_index %d\n", client_fd_index);
        }

        if (ready_descriptors > 0) {
            // look at client descriptors now
            for (auto clifd = 0; clifd <= client_fd_index; ++clifd) {
                if (client_fds[clifd] < 0)
                    continue;
                if (FD_ISSET(client_fds[clifd], &tmp_fds)) {
                    int bytes_read;
                    bytes_read = read(client_fds[clifd], bytes, 12);
                    bytes[13] = 0;
                    if (bytes_read < 0) {
                        printf("%s\n", "Error during reading exchange data");
                        return -1;
                    }
                    /* else if (bytes_read == 0) {
                        // close socket
                        close(client_fds[clifd]);
                        FD_CLR(client_fds[clifd], &descriptors);
                        client_fds[clifd] = -1;
                        printf("Closing socket for fd %d\n", clifd);
                    } */
                    else {
                        uint32_t exchange =
                            static_cast<uint32_t>(bytes[3]) |
                            static_cast<uint32_t>(bytes[2]) << 8 |
                            static_cast<uint32_t>(bytes[1]) << 16 |
                            static_cast<uint32_t>(bytes[0]) << 24;
                            
                        uint64_t stock =
                            static_cast<uint64_t>(bytes[11]) |
                            static_cast<uint64_t>(bytes[10]) << 8 |
                            static_cast<uint64_t>(bytes[9]) << 16 |
                            static_cast<uint64_t>(bytes[8]) << 24 |
                            static_cast<uint64_t>(bytes[7]) << 32 |
                            static_cast<uint64_t>(bytes[6]) << 40 |
                            static_cast<uint64_t>(bytes[5]) << 48 |
                            static_cast<uint64_t>(bytes[4]) << 56;
                        if (stock == 0) {
                            close(client_fds[clifd]);
                            FD_CLR(client_fds[clifd], &descriptors);
                            client_fds[clifd] = -1;
                        } else {
                            printf("%llu, %lu\n", stock, exchange);
                        }
                    }
                }
                --ready_descriptors;
                if (!ready_descriptors)
                    break;
            }
        }  // end of if (ready_descrip..)
    }  // end of while(true) loop
    return 0;
}
