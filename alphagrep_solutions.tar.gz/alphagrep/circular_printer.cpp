// Copyright (C) 2016 by RajatGirotra
#include <iostream>
#include <thread>
#include <condition_variable>
#include <mutex>
#include <string>
#include <vector>
#include <cassert>
using std::cout;
using std::endl;
using std::string;
using std::vector;

// synchronization variables
int turn {};
std::mutex mtx;
std::condition_variable cond;

void runner(int thread_number, const std::string& str,
            int char_count, int total_threads, int iterations) {
    for (int iter = 0; iter < iterations; ++iter) {
        {
            std::unique_lock<std::mutex> lck(mtx);
            while (turn != thread_number) {
                cond.wait(lck);
            }
            // Logic for printing
            cout << "Thread" << thread_number+1 << ": ";
            auto pos = (thread_number + (iter * total_threads)) * char_count;
            pos = pos % str.size();
            if (str.size() - pos < char_count) {
                cout << str.substr(pos);
                cout << str.substr(0, char_count-(str.size()-pos));
            } else {
                cout << str.substr(pos, char_count);
            }
            cout << "\n";
            turn = (turn + 1) % total_threads;
        }
        cond.notify_all();
    }
}

int main(int argc, char* argv[]) {
    if (argc != 5) {
        cout << "Usage:\n\t" << argv[0]
             << " <string> <char_count> <thread_count> <iterations>\n";
        return -1;
    }

    vector<std::thread> thread_list;
    string str(argv[1]);
    // char_count must be less than equal to string size
    assert(atoi(argv[2]) <= str.size());
    for (int thread_number = 0; thread_number < atoi(argv[3]); ++thread_number) {
        thread_list.push_back(
            std::thread(runner, thread_number, str, atoi(argv[2]),
                        atoi(argv[3]), atoi(argv[4])));
    }

    for (auto& th : thread_list)
        th.join();

    return 0;
}
